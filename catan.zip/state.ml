open Board

type t = int

let build_house board pos = failwith "Unimplemented"

let build_road board pos = failwith "Unimplemented"
