let hours_worked = [ 60; 60; 60; 60 ]
