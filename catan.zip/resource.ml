(** The type representing resources. *)
type t =
  | Wheat
  | Ore
  | Wool
  | Brick
  | Wood
